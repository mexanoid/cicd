configuration OctopusServer
{
    param (
        [parameter(Mandatory)]
        [PSCredential]
        $Credential,
        [parameter(Mandatory)]
        [String]
        $WebListenPrefix
        )

    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'    
    Import-DscResource -ModuleName OctopusDSC 
    Import-DscResource -ModuleName SqlServerDsc
    Import-DscResource -ModuleName StorageDsc

    Import-DSCResource -Name WindowsFeature

    Node "Download"
    {
        File CreateMediaDir
        {
            Type = 'Directory'
            DestinationPath = 'C:\InstallMedia'
            Ensure = "Present"
        }
        
        Script DownloadISO
        {
            GetScript = 
            {
                @{
                    GetScript = $GetScript
                    SetScript = $SetScript
                    TestScript = $TestScript
                    Result = ('True' -in (Test-Path C:\InstallMedia\en_sql_server_2017_developer_x64_dvd_11296168.iso))
                }
            }

            SetScript = 
            {
                Invoke-WebRequest -Uri "https://infrastorm.blob.core.windows.net/dsc/en_sql_server_2017_developer_x64_dvd_11296168.iso" -OutFile "C:\InstallMedia\en_sql_server_2017_developer_x64_dvd_11296168.iso"
            }

            TestScript = 
            {
                $Status = ('True' -in (Test-Path C:\InstallMedia\en_sql_server_2017_developer_x64_dvd_11296168.iso))
                $Status -eq $True
            }
        }
    }

    Node "localhost"
    {
        WaitForAll Download
        {
            ResourceName      = '[Script]DownloadISO'
            NodeName          = 'Download'
            RetryIntervalSec  = 130
            RetryCount        = 30
        }

        MountImage ISO
        {
            ImagePath   = 'C:\InstallMedia\en_sql_server_2017_developer_x64_dvd_11296168.iso'
            DriveLetter = 'S'
            DependsOn   = '[WaitForAll]Download'
        }

        WaitForVolume WaitForISO
        {
            DriveLetter      = 'S'
            RetryIntervalSec = 10
            RetryCount       = 20
        }

        WindowsFeature 'NetFramework45'
        {
            Name   = 'NET-Framework-45-Core'
            Ensure = 'Present'
        }

        SqlSetup InstallDefaultInstance
        {
            Action                 = "Install"
            SourcePath             = 'S:\'
            InstanceName           = 'MSSQLSERVER'
            Features               = 'SQLENGINE'
            SQLCollation           = 'SQL_Latin1_General_CP1_CI_AS'
            PsDscRunAsCredential   = $Credential
            SQLSysAdminAccounts    = @('Administrators')
            UpdateEnabled          = 'False'
            ForceReboot            = $false
            InstallSharedDir       = 'C:\Program Files\Microsoft SQL Server'
            InstallSharedWOWDir    = 'C:\Program Files (x86)\Microsoft SQL Server'
            InstanceDir            = 'C:\Program Files\Microsoft SQL Server'
            InstallSQLDataDir      = 'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\Data'
            SQLUserDBDir           = 'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\Data'
            SQLUserDBLogDir        = 'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\Data'
            SQLTempDBDir           = 'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\Data'
            SQLTempDBLogDir        = 'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\Data'
            SQLBackupDir           = 'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\Backup'
            DependsOn              =  '[WindowsFeature]NetFramework45', '[MountImage]ISO'
        }
    }
}
